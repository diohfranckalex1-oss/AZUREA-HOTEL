const menuBtn=document.querySelector('.menu-toggle'),nav=document.querySelector('.nav');
menuBtn.addEventListener('click',()=>{const open=nav.classList.toggle('open');menuBtn.setAttribute('aria-expanded',String(open));});
nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')));
const today=new Date();const iso=d=>{const x=new Date(d.getTime()-d.getTimezoneOffset()*60000);return x.toISOString().slice(0,10)};
const inEl=document.getElementById('checkin'),outEl=document.getElementById('checkout');inEl.min=iso(today);outEl.min=iso(new Date(today.getTime()+86400000));
inEl.addEventListener('change',()=>{const d=new Date(inEl.value+'T12:00:00');d.setDate(d.getDate()+1);outEl.min=iso(d);if(outEl.value&&outEl.value<=inEl.value)outEl.value='';});
const modal=document.getElementById('booking-modal');
document.getElementById('booking-form').addEventListener('submit',e=>{e.preventDefault();if(!inEl.value||!outEl.value||outEl.value<=inEl.value){document.getElementById('booking-feedback').textContent='Veuillez choisir une date de départ après la date d’arrivée.';return;}
const fmt=v=>new Date(v+'T12:00:00').toLocaleDateString('fr-FR',{day:'2-digit',month:'long',year:'numeric'});
document.getElementById('modal-summary').textContent=`Arrivée : ${fmt(inEl.value)} · Départ : ${fmt(outEl.value)} · ${document.getElementById('guests').value}.`;
modal.classList.add('open');});
document.querySelector('.modal-close').addEventListener('click',()=>modal.classList.remove('open'));
document.querySelector('.modal-ok').addEventListener('click',()=>modal.classList.remove('open'));
modal.addEventListener('click',e=>{if(e.target===modal)modal.classList.remove('open')});
