# AZURÉA — Démonstration de site hôtelier

Prototype responsive en HTML, CSS et JavaScript, avec les six photos fournies.

## Lancer le site
Ouvrir `index.html` dans un navigateur. Aucun outil de compilation n'est nécessaire.

## Fonctionnalités de démonstration
- Présentation de l'hôtel, chambres, expériences et galerie
- Navigation mobile
- Formulaire de demande de séjour avec validation des dates
- Fenêtre de confirmation de démonstration

## Important
AZURÉA, les textes et les coordonnées sont fictifs. Le formulaire n'envoie et ne stocke aucune réservation. Avant une mise en production, il faudra connecter le formulaire à un backend sécurisé (par exemple Supabase), créer une table de réservations avec politiques RLS, ajouter une validation serveur et un tableau de bord administrateur protégé.

## Personnalisation
Remplacer le nom, les textes, les photos, les coordonnées, les tarifs et les informations de l'établissement par les éléments autorisés du client.
